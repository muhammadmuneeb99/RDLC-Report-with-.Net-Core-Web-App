﻿using System.Data;
using System.Data.SqlClient;

namespace RDLCReportCore.Models
{
    public class InfoService
    {
        private string _connectionString = "Data Source=DESKTOP-BUHJHV5;Integrated Security=SSPI;Initial Catalog=AdventureWorksDW2022";

        public DataTable GetInfo()
        {
            var dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SPGetInfo", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                connection.Open();

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
                connection.Close();
            }
            return dt;
        }
    }
}
