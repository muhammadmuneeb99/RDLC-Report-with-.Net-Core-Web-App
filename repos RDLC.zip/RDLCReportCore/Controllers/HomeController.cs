﻿using AspNetCore.Reporting;

using Microsoft.AspNetCore.Mvc;

using RDLCReportCore.Models;

using System.Data;
using System.Diagnostics;

namespace RDLCReportCore.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly IWebHostEnvironment _webHostEnvironment;

        public InfoService infoService = new InfoService();

        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger;
            _webHostEnvironment = webHostEnvironment;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Info()
        {
            var dt = new DataTable();
            dt = infoService.GetInfo();

            string mimeType = "";
            int extension = 1;

            var path = $"{_webHostEnvironment.WebRootPath}\\Reports\\Info.rdlc";
            //var path = "C:\\Users\\Muhammad Muneeb\\source\\repos\\RDLCReportCore\\wwwroot\\Reports\\Info.rdlc";
            Dictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("prm1", "RDLC Report");
            parameters.Add("prm2", DateTime.Now.ToString("dd-MMM-yyyy"));
            parameters.Add("prm3", "Info Report");

            LocalReport localReport = new LocalReport(path);
            localReport.AddDataSource("dsInfo", dt);
            var res = localReport.Execute(RenderType.Pdf, extension, parameters, mimeType);

            return File(res.MainStream, "application/pdf");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}