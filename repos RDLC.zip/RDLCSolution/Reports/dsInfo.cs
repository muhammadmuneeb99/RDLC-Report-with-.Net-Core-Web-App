﻿namespace RDLCSolution.Reports
{


    public partial class dsInfo
    {
    }
}
namespace RDLCSolution.Reports {
    
    
    public partial class dsInfo {
    }
}
